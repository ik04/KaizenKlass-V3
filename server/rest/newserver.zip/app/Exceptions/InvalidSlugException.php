<?php

namespace App\Exceptions;

use Exception;

class InvalidSlugException extends Exception
{
    //
}
