<?php

namespace App\Exceptions;

use Exception;

class SelectionNotFoundException extends Exception
{
    //
}
