<?php

namespace App\Exceptions;

use Exception;

class EmptyDescriptionException extends Exception
{
    //
}
