<?php

namespace App\Exceptions;

use Exception;

class InvalidSubjectResourceUuidException extends Exception
{
    //
}
