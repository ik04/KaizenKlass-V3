<?php

namespace App\Exceptions;

use Exception;

class AlreadyPromotedException extends Exception
{
    //
}
