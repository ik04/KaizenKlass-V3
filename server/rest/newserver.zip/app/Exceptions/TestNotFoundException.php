<?php

namespace App\Exceptions;

use Exception;

class TestNotFoundException extends Exception
{
    //
}
