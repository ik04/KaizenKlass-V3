<?php

namespace App\Exceptions;

use Exception;

class TestAlreadyExistsException extends Exception
{
    //
}
