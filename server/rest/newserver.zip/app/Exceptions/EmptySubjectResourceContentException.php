<?php

namespace App\Exceptions;

use Exception;

class EmptySubjectResourceContentException extends Exception
{
    //
}
