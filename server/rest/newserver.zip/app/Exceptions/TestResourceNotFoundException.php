<?php

namespace App\Exceptions;

use Exception;

class TestResourceNotFoundException extends Exception
{
    //
}
