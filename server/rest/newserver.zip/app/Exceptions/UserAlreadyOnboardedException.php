<?php

namespace App\Exceptions;

use Exception;

class UserAlreadyOnboardedException extends Exception
{
    //
}
