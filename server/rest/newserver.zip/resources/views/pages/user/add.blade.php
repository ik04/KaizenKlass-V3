@extends('layout/user-layout')
@section('content')
    <h4 class="text-black">Add User</h4>
    @include('includes/success-message')
    @include('includes/user/register-form')
@endsection
